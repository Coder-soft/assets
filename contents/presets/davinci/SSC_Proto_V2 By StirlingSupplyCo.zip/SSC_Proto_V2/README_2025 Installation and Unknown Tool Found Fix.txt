Thanks for checking out Proto!


For the most up-to-date Information in Instalaltion issues, Uknown Tool Found Error Messages, and access to the fusion page version of Proto, please see the linked video below


https://youtu.be/Uf9RPbYBWoE


Thank you
 - Patrick Stirling